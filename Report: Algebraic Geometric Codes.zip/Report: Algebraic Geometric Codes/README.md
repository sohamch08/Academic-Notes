# algorithmic-coding-theory-aks
We keep the files related to the Report on Algebraic Geometric Codes for the Algorithmic Coding Theory Course taken by Amit Kumar Sinhababu.
